export declare function error(message: string | undefined, error?: any, path?: string | undefined): void;
export declare function info(message: string, params?: any): void;
export declare function redis(message: string, params?: any): void;
export declare function database(message: string, params?: any): void;

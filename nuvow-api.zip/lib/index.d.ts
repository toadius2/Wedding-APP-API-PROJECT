declare global {
    interface Array<T> {
        toJSON(options?: any): any;
        unique(property?: string): Array<T>;
    }
}
export {};

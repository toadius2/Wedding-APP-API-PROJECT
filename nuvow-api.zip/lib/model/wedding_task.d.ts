import * as base from "./base";
import * as Sequelize from "sequelize";
export interface WeddingTaskAttributes extends base.BaseModelAttributes {
    name: string;
    completed: boolean;
}
export interface WeddingTaskInstance extends Sequelize.Instance<WeddingTaskAttributes>, WeddingTaskAttributes {
    wedding_id: String;
}
export declare let WeddingTask: Sequelize.Model<WeddingTaskInstance, WeddingTaskAttributes>;
export declare function define(sequelize: Sequelize.Sequelize): void;

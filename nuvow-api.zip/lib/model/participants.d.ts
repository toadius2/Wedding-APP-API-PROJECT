import * as base from "./base";
import * as Sequelize from "sequelize";
export interface ParticipantsAttributes extends base.BaseModelAttributes {
    email: string;
    status: string;
}
export interface ParticipantsInstance extends Sequelize.Instance<ParticipantsAttributes>, ParticipantsAttributes {
}
export declare let Participants: Sequelize.Model<ParticipantsInstance, ParticipantsAttributes>;
export declare function define(sequelize: Sequelize.Sequelize): void;

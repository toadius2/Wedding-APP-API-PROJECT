import * as Sequelize from "sequelize";
export default function setup(s: Sequelize.Sequelize): void;

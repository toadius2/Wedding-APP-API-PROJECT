import * as base from "./base";
import * as Sequelize from "sequelize";
import * as User from "./user";
export interface DeviceAttributes extends base.BaseModelAttributes {
    app_version: string;
    build_version: string;
    device_token?: string;
    token_provider?: string;
    device_uuid: string;
    device_data_os?: string;
    device_data_os_version?: string;
    device_data_device_type?: string;
    device_data_device_name?: string;
    device_data_device_category?: string;
    device_data_carrier?: string;
    device_data_battery?: string;
    debug: boolean;
    language: string;
    valid: boolean;
    session_token: string | undefined;
    User?: User.UserInstance | any;
    sns_endpoint?: string | undefined;
    user_id?: string;
    badge?: number;
}
export interface DeviceInstance extends Sequelize.Instance<DeviceAttributes>, DeviceAttributes {
    sendPush: (content: string, inc: boolean, meta?: any) => Promise<void>;
    updateEndpoint: () => Promise<any>;
}
export declare let Device: Sequelize.Model<DeviceInstance, DeviceAttributes>;
export declare function define(sequelize: Sequelize.Sequelize): void;

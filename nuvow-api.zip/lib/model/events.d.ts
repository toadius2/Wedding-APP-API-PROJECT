import * as base from "./base";
import * as Sequelize from "sequelize";
import { ParticipantsAttributes, ParticipantsInstance } from "./participants";
export interface EventsAttributes extends base.BaseModelAttributes {
    name: string;
    date: Date;
    duration: Number;
    color?: string;
}
export interface EventsInstance extends Sequelize.Instance<EventsAttributes>, EventsAttributes {
    wedding_id: string;
    participants: Array<ParticipantsInstance>;
    createParticipant: Sequelize.HasManyCreateAssociationMixin<ParticipantsAttributes, ParticipantsInstance>;
    removeParticipant: Sequelize.HasManyRemoveAssociationMixin<ParticipantsAttributes, string>;
}
export declare let Events: Sequelize.Model<EventsInstance, EventsAttributes>;
export declare function define(sequelize: Sequelize.Sequelize): void;

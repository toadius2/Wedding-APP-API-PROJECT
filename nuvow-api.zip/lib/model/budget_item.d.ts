import * as base from "./base";
import * as Sequelize from "sequelize";
export interface BudgetItemAttributes extends base.BaseModelAttributes {
    amount: number;
    name: string;
    color?: string;
}
export interface BudgetItemInstance extends Sequelize.Instance<BudgetItemAttributes>, BudgetItemAttributes {
    wedding_id: String;
}
export declare let BudgetItem: Sequelize.Model<BudgetItemInstance, BudgetItemAttributes>;
export declare function define(sequelize: Sequelize.Sequelize): void;

import * as base from "./base";
import * as Sequelize from "sequelize";
export interface EventParticipantAttributes extends base.BaseModelAttributes {
    email: string;
    status: string;
}
export interface EventParticipantInstance extends Sequelize.Instance<EventParticipantAttributes>, EventParticipantAttributes {
}
export declare let EventParticipant: Sequelize.Model<EventParticipantInstance, EventParticipantAttributes>;
export declare function define(sequelize: Sequelize.Sequelize): void;

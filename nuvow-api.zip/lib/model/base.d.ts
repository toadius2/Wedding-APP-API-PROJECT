import * as Sequelize from "sequelize";
export interface BaseModelAttributes {
    id?: string;
    created_at?: Date;
    updated_at?: Date;
    deleted_at?: Date | null;
}
export declare function defaultColums(): Sequelize.DefineAttributes;

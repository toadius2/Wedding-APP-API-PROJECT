import * as base from "./base";
import * as Sequelize from "sequelize";
export interface WeddingTimelineAttributes extends base.BaseModelAttributes {
    title: string;
    time: Date;
}
export interface WeddingTimelineInstance extends Sequelize.Instance<WeddingTimelineAttributes>, WeddingTimelineAttributes {
    wedding_id: String;
}
export declare let WeddingTimeline: Sequelize.Model<WeddingTimelineInstance, WeddingTimelineAttributes>;
export declare function define(sequelize: Sequelize.Sequelize): void;

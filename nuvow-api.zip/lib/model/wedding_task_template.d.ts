import * as base from "./base";
import * as Sequelize from "sequelize";
export interface WeddingTaskTemplateAttributes extends base.BaseModelAttributes {
    name: string;
}
export interface WeddingTaskTemplateInstance extends Sequelize.Instance<WeddingTaskTemplateAttributes>, WeddingTaskTemplateAttributes {
}
export declare let WeddingTaskTemplate: Sequelize.Model<WeddingTaskTemplateInstance, WeddingTaskTemplateAttributes>;
export declare function define(sequelize: Sequelize.Sequelize): void;

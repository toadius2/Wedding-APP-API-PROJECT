import * as base from "./base";
import * as Sequelize from "sequelize";
import { EventParticipantAttributes, EventParticipantInstance } from "./participant";
export interface EventAttributes extends base.BaseModelAttributes {
    title: string;
    location?: string;
    notes?: string;
    date: Date;
    duration: number;
    color?: string;
}
export interface EventInstance extends Sequelize.Instance<EventAttributes>, EventAttributes {
    readonly end_date: Date;
    wedding_id: string;
    participants: Array<EventParticipantInstance>;
    createParticipant: Sequelize.HasManyCreateAssociationMixin<EventParticipantAttributes, EventParticipantInstance>;
    removeParticipant: Sequelize.HasManyRemoveAssociationMixin<EventParticipantInstance, string>;
}
export declare let Event: Sequelize.Model<EventInstance, EventAttributes>;
export declare function define(sequelize: Sequelize.Sequelize): void;

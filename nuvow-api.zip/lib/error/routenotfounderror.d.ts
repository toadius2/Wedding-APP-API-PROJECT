import BasicError from "./baseerror";
/**
 * This error class indicates a routenotfounderror
 */
export default class RouteNotFoundError extends BasicError {
    path: string;
    type: string;
    status: number;
    /**
     * Constructs a new RouteNotFoundError
     * @param message - The error message
     */
    constructor(message?: string, path?: string);
}

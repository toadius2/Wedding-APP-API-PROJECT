import BasicError from "./baseerror";
/**
 * This error class indicates a ResourceAlreadyExists
 */
export default class ResourceAlreadyExists extends BasicError {
    type: string;
    status: number;
    existing_keys: string[];
    /**
     * Constructs a new ResourceAlreadyExists
     * @param message - The error message
     * @param existing_keys - The keys that were duplicated
     */
    constructor(message?: string, existing_keys?: string[]);
    toErrorJSON(): any;
}

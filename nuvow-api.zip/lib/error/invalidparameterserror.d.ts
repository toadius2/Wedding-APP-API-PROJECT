import BasicError from "./baseerror";
/**
 * This error class indicates a invalidparameterserror
 */
export default class InvalidParametersError extends BasicError {
    type: string;
    status: number;
    missingKeys: Array<string>;
    invalidKeys: {
        [key: string]: string;
    };
    /**
     * Initializes a new InvalidParametersError
     * @param {Array<string>} missingParameters
     * @param {Array<string>} invalidParameters
     * @param {string} message
     */
    constructor(missingParameters: Array<string>, invalidParameters: {
        [key: string]: string;
    }, message?: string);
    toErrorJSON(): any;
}

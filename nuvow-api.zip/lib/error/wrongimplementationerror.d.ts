import BasicError from "./baseerror";
/**
 * This error class indicates a WrongImplementationError
 */
export default class WrongImplementationError extends BasicError {
    type: string;
    status: number;
    /**
     * Constructs a new WrongImplementationError
     * @param message - The error message
     */
    constructor(message?: string);
}

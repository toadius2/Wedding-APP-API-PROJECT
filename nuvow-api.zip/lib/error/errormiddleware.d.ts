import BasicError from "./baseerror";
export declare let prepareErrorForResponse: (err: Error, route?: string | undefined) => BasicError;

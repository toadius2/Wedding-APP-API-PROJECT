import BasicError from "./baseerror";
/**
 * This error class indicates a NoWeddingFoundError
 */
export default class NoWeddingFoundError extends BasicError {
    type: string;
    status: number;
    /**
     * Constructs a new NoWeddingFoundError
     * @param message - The error message
     */
    constructor(message?: string);
}

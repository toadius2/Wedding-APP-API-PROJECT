import BasicError from "./baseerror";
/**
 * This error class indicates a notaccessibleerror
 */
export default class NotAccessibleError extends BasicError {
    type: string;
    status: number;
    /**
     * Constructs a new NotAccessibleError
     * @param message - The error message
     */
    constructor(message?: string);
}

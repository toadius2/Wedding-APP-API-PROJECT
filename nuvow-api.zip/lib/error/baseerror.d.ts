export default class BasicError extends Error {
    isCritical?: boolean;
    type: string;
    status: number;
    message: string;
    constructor(message?: any);
    toErrorJSON(): any;
}

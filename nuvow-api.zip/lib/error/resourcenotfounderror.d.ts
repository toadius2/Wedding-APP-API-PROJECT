import BasicError from "./baseerror";
/**
 * This error class indicates a ResourceAlreadyExists
 */
export default class ResourceNotFoundError extends BasicError {
    type: string;
    status: number;
    resource_type: string;
    /**
     * Constructs a new ResourceNotFoundError
     * @param message - The error message
     */
    constructor(message: string | undefined, resource_type: string);
    toErrorJSON(): any;
}

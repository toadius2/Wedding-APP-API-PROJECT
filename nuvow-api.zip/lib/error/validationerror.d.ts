import BasicError from "./baseerror";
/**
 * This error class indicates a validationerror
 */
export default class ValidationError extends BasicError {
    type: string;
    status: number;
    missingKeys: Array<string>;
    invalidKeys: Array<string>;
    /**
     * Constructs a new ValidationError
     * @param errors - The errors that happened
     * @param message - The error message
     */
    constructor(errors?: Object, message?: string);
}

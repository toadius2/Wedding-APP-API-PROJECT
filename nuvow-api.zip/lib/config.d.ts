export declare const DOMAINS: string[];

import * as AWS from "aws-sdk";
export default class EmailServer {
    private SES;
    /**
     * Construct a new email server
     */
    constructor();
    /**
     * sends an email 'from' 'to'
     * @param to - must be an Array
     * @param subject
     * @param text
     * @param bcc - if set, must be an array
     * @param from - optional
     * @returns {Promise}
     */
    send(to: AWS.SES.AddressList | AWS.SES.Address, subject: AWS.SES.MessageData, text: AWS.SES.MessageData, bcc?: AWS.SES.AddressList, from?: AWS.SES.Address): Promise<AWS.SES.SendEmailResponse>;
}

/// <reference types="node" />
import BasicError from "../error/baseerror";
export declare class UnsupportedVideoCodedError extends BasicError {
    codec_name: any;
    supported_codecs: string[];
    constructor(message?: string, codec?: string);
}
export declare class VideoDetectionError extends BasicError {
    underlyingError?: any;
    constructor(message?: string, err?: any);
}
export interface VideoData {
    format: string;
    duration: number;
    codec_type: string;
    type: string;
    data: Buffer;
    thumbnail?: string;
}
export declare function detectVideoData(filePath: string, generateThumbnail: boolean, convertToMpeg?: boolean): Promise<VideoData>;

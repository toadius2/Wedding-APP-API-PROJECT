export declare class PushServer {
    private SNS;
    /**
     * Construct a new push server
     * @param options - The options to pass to AWS sdk
     */
    constructor();
    /**
     * Register a new device to the push service
     * @param applicationARN - The applications ARN
     * @param {String} deviceToken - The token of the device
     * @returns {Promise}
     */
    registerNewDevice(applicationARN: string, deviceToken: string): Promise<any>;
    /**
     * Update a devices token
     * @param endpointARN - The ARN of the endpoint
     * @param newDeviceToken - The new device token
     * @returns {Promise}
     */
    updateDeviceToken(endpointARN: string, newDeviceToken: string): Promise<any>;
    /**
     * Removes a device
     * @param endpointARN - The ARN of the endpoint
     * @returns {Promise}
     */
    removeEndpoint(endpointARN: string): Promise<any>;
    /**
     * Sends a push notification to the endpoint
     * @param endpointARN - The ARN of the devices endpoint
     * @param message - The message text to send to the device
     * @param additionalAttributes - Any additional APS payload to include in the message
     * @returns {Promise}
     */
    sendPushToEndpoint(endpointARN: string, message: string, additionalAttributes?: string): Promise<any>;
    /**
     * Sends a push notification to a group of devices
     * @param topicArn - The ARN of the topic
     * @param message - The message text to send to the topic
     * @param additionalAttributes - Any additional APS payload to include in the message
     * @returns {Promise}
     */
    sendPushToTopic(topicArn: string, message: string, additionalAttributes?: string): Promise<any>;
    /**
     * Creates a new topic
     * @param name - The name of the topic
     * @returns {Promise}
     */
    createTopic(name: string): Promise<any>;
    /**
     * Removes a topic
     * @param topicArn - The ARN of the topic
     * @returns {Promise}
     */
    removeTopic(topicArn: string): Promise<any>;
    /**
     * Subscribes a device to a topic
     * @param endpointArn - The ARN of the device endpoint
     * @param topicArn - The ARN of the topic
     * @returns {Promise}
     */
    subscribe(endpointArn: string, topicArn: string): Promise<any>;
    /**
     * Removes a subscription
     * @param subscriptionArn - The ARN of the subscription
     * @returns {Promise}
     */
    unsubscribe(subscriptionArn: string): Promise<any>;
}
/**
 * Merge obj1 with obj2
 * @param obj1
 * @param obj2
 * @returns mixed
 */
export declare function mergeRecursive(obj1: any, obj2: any): any;

/// <reference types="node" />
import { S3 } from "aws-sdk";
export default function s3Upload(key: string, data: Buffer, contenType: 'image' | 'video'): Promise<S3.PutObjectOutput>;

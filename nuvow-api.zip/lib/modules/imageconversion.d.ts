/// <reference types="node" />
export declare class ImageDetectionError extends Error {
    underlyingError?: any;
    constructor(message?: string, err?: any);
}
export interface ImageData {
    size: {
        width: number;
        height: number;
    };
    format: string;
    type: string;
}
export declare function detectImageData(filePath: string): Promise<ImageData>;
export declare function imageToBuffer(filePath: string, quality?: number, width?: number): Promise<Buffer>;
export declare function resize(filePath: string, size: {
    width: number;
    height: number;
}, quality?: number): Promise<Buffer>;
export declare function download(image: string): Promise<Buffer>;
export declare function donwloadImage(image: string): Promise<string>;
export declare function removeLocalFile(image: string): void;
export declare function promotePicture(localImage: string, watermark: string): Promise<Buffer>;
export declare function mosaic(images: Array<string>): Promise<string>;

export default function findMentionedUser(content: string): Array<String>;

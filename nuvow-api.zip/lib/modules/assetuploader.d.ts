export declare class Uploader {
    private pipeline;
    imageRatio: Number;
    constructor();
    image(fromPath: string, to: string, newWidth?: number, quality?: number, onlyOriginal?: boolean): Uploader;
    video(fromPath: string, to: string, convert?: boolean): Uploader;
    exec(): Promise<any>;
}

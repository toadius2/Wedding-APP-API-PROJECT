import * as sequelize from "sequelize";
export default class DataBase {
    private connection;
    constructor(database: string, username: string, password: string, host: string, readHost?: string);
    connect(): Promise<sequelize.Sequelize>;
    define(): any;
}

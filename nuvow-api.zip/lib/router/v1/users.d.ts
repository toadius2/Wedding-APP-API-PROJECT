import { BasicRouter } from "../basicrouter";
export declare class UsersRouter extends BasicRouter {
    constructor();
    /**
     * Returns the current user
     * @param {APIRequest} req
     * @param {e.Response} res
     * @param {e.NextFunction} next
     */
    private static getUser;
    /**
     * Returns the users handle if the users email address is known
     * @param {APIRequest} req
     * @param {e.Response} res
     * @param {e.NextFunction} next
     */
    private static getUserByEmail;
    /**
     * Registers a new user using email or (registers / logs in) a facebook user
     * @param {APIRequest<RegistrationBodyParameters>} req
     * @param {e.Response} res
     * @param {e.NextFunction} next
     */
    private static newUser;
    private static newGoogleUser;
    private static newFacebookUser;
    private static removeProfilePicture;
    private static processProfilePicture;
}

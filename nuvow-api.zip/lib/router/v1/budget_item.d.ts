import { BasicRouter } from "../basicrouter";
export declare class BudgetItemRouter extends BasicRouter {
    constructor();
    private static getItems;
    private static newBudgetItem;
    private static updateBudgetItem;
    /**
     * This function deletes a budget item
     * @param {APIRequest} req
     * @param {e.Response} res
     * @param {e.NextFunction} next
     */
    private static deleteItem;
}

import { BasicRouter } from "../basicrouter";
export declare class WeddingRouter extends BasicRouter {
    constructor();
    private static getWedding;
    private static newWedding;
    private static updateWedding;
}

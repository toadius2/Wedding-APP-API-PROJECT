import { APIRequest, BasicRouter } from "../basicrouter";
import { DeviceAttributes, DeviceInstance, UserInstance } from "../../model";
export declare class DevicesRouter extends BasicRouter {
    constructor();
    static findOrCreateDevice(device: DeviceAttributes, user: UserInstance, req: APIRequest): Promise<[boolean, DeviceInstance]>;
    static castUpdateDeviceBody(body: any): any;
    /**
     * This function deletes a device and unregisters it from SNS
     * @param {APIRequest} req
     * @param {e.Response} res
     * @param {e.NextFunction} next
     */
    private static deleteDevice;
}

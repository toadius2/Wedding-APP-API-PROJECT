import { BasicRouter } from "../basicrouter";
export declare class WeddingTimelineRouter extends BasicRouter {
    constructor();
    private static getWeddingTimeline;
    private static newWeddingTimeline;
    private static updateWeddingTimeline;
    private static deleteWeddingTimeline;
}

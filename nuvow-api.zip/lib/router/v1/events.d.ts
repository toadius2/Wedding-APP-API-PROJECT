import { BasicRouter } from "../basicrouter";
export declare class EventsRouter extends BasicRouter {
    constructor();
    private static getEvents;
    private static getEvent;
    private static newEvent;
    private static updateEvent;
    private static deleteEvent;
}

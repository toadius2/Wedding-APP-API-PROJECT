import { BasicRouter } from "../basicrouter";
export declare const Router: BasicRouter[];

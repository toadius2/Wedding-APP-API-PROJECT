import * as express from "express";
import { APIRequest, BasicRouter, APIResponse } from "../basicrouter";
import { DeviceAttributes } from "../../model";
export declare class LoginRouter extends BasicRouter {
    constructor();
    static logout(req: APIRequest<LoginData>, res: APIResponse, next: express.NextFunction): void;
    static verify(req: APIRequest<{
        code: string;
    }>, res: APIResponse, next: express.NextFunction): void;
    static doLogin(data: {
        email: string;
        password: string;
    }): Promise<import("../../model").UserInstance>;
    /**
     * This function checks a users login data and returns the user
     * @param {APIRequest<LoginData>} req
     * @param {e.Response} res
     * @param {e.NextFunction} next
     */
    static login(req: APIRequest<LoginData>, res: APIResponse, next: express.NextFunction): void;
    /**
     * This function sends a password reset email to the provided email address if a user with that address was found
     * @param {APIRequest<{email: string}>} req
     * @param {e.Response} res
     * @param {e.NextFunction} next
     */
    static forgotPassword(req: APIRequest<{
        email: string;
    }>, res: APIResponse, next: express.NextFunction): void;
    /**
     * Resets the users password if the provided code (which is received by email) matches one in the database
     * @param {APIRequest<{code: string; password: string}>} req
     * @param {e.Response} res
     * @param {e.NextFunction} next
     */
    static resetPassword(req: APIRequest<{
        code: string;
        password: string;
    }>, res: APIResponse, next: express.NextFunction): void;
    /**
     * Changes the password of the currently logged in user if the old_password parameter matches the current one
     * @param {APIRequest<{old_password: string; password: string}>} req
     * @param {e.Response} res
     * @param {e.NextFunction} next
     */
    static changePassword(req: APIRequest<{
        old_password: string;
        password: string;
    }>, res: APIResponse, next: express.NextFunction): void;
}
export interface LoginData {
    email: string;
    password: string;
    device: DeviceAttributes;
}

import { BasicRouter } from "../basicrouter";
export declare class WeddingTaskRouter extends BasicRouter {
    constructor();
    private static getWeddingTask;
    private static newWeddingTask;
    private static updateWeddingTask;
    private static deleteWeddingTask;
}

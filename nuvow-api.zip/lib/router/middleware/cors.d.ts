import * as express from "express";
import { APIRequest, APIResponse } from "../basicrouter";
export default function applyCORS(req: APIRequest, res: APIResponse, next: express.NextFunction): void;

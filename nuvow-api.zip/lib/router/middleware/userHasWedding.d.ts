import * as express from "express";
import { APIRequest, APIResponse } from "../basicrouter";
/**
 * This function checks if the current user has wedding
 * @param {APIRequest} req
 * @param {e.Response} res
 * @param {e.NextFunction} next
 */
export declare function hasWedding(req: APIRequest, res: APIResponse, next: express.NextFunction): void;

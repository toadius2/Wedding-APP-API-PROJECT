import BasicError from "../../error/baseerror";
/**
 * This interface defines the data returned from a google token validation
 */
export interface GoogleAuthenticationData {
    name: string;
    email?: string;
    id: string;
}
/**
 * This class defines a generic error when communicating with the google API
 */
export declare class GenericGoogleError extends BasicError {
    encapsulatedError?: any;
    constructor(message?: string, error?: any);
}
/**
 * This class defines an error with the google api when the provided authentication token is not valid or expired
 */
export declare class GoogleTokenExpiredError extends GenericGoogleError {
    constructor(message?: string, error?: any);
}
/**
 * This function returns a promise containing GoogleAuthenticationData
 * @param {string} google_token - A google authentication token with email access right
 * @returns {Promise<GoogleAuthenticationData>}
 */
export declare function validateGoogleToken(google_token: string): Promise<GoogleAuthenticationData>;

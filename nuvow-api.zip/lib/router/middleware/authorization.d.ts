import * as express from "express";
import { APIRequest, APIResponse } from "../basicrouter";
/**
 * This function checks if the provided auth token exists and sets the current device and the current user
 * @param {APIRequest} req
 * @param {e.Response} res
 * @param {e.NextFunction} next
 */
export declare function isAuthorized(req: APIRequest, res: APIResponse, next: express.NextFunction): void;
/**
 * This function checks if the provided auth token exists and sets the current device and the current user
 * @param {APIRequest} req
 * @param {e.Response} res
 * @param {e.NextFunction} next
 */
export declare function isAuthorizedOptional(req: APIRequest, res: APIResponse, next: express.NextFunction): void;
export declare function isAdmin(req: APIRequest, res: APIResponse, next: express.NextFunction): void;
/**
 * This function checks if the provided refresh token exists and sets the current user
 * @param {APIRequest} req
 * @param {e.Response} res
 * @param {e.NextFunction} next
 */
export declare function isRefreshTokenAuthorized(req: APIRequest, res: APIResponse, next: express.NextFunction): void;

/**
 * This interface defines a basic outline for a validator function
 */
export interface ValidatorFunction<T> {
    (value: T): true | string;
}
/**
 * This rule detects if the provided value is a string
 * @param value
 * @param allowEmpty
 * @returns {boolean}
 */
export declare function isStringAndNotEmpty(value: any): true | string;
/**
 * This rule detects if the provided value is a string
 * @param value
 * @param allowEmpty
 * @returns {boolean}
 */
export declare function isString(value: any, allowEmpty?: boolean): true | string;
/**
 * This rule detects if the provided value is a valid email
 * @param value
 * @returns {boolean}
 */
export declare function isEmail(value: any): true | string;
/**
 * This rule detects if the provided value is an array
 * @param value
 * @returns {boolean}
 */
export declare function isArray(value: any): true | string;
export declare function isDate(value: any): true | string;
/**
 * This rule detects if the provided value is an array
 * @param ofType
 * @returns {boolean}
 */
export declare function isArrayOfType(ofType: string): ValidatorFunction<any>;
/**
 * This rule detects if the provided value is a number
 * @param value
 * @returns {boolean}
 */
export declare function isNumber(value: any): true | string;
/**
 * This rule detects if the provided value exists
 * @param value
 * @returns {boolean}
 */
export declare function isExists(value: any): true | string;
/**
 * This rule detects if the provided value is an object
 * @param value
 * @returns {boolean}
 */
export declare function isObject(value: any): true | string;
/**
 * This rule detects if the provided value is a boolean
 * @param value
 * @returns {boolean}
 */
export declare function isBoolean(value: any): true | string;
/**
 * This rule detects if the provided string has a minimum length
 * @param {number} length
 * @returns {ValidatorFunction<string>}
 */
export declare function minLength(length: number): ValidatorFunction<string>;
/**
 * This rule detects if the provided string is below a maximum length
 * @param {number} length
 * @returns {ValidatorFunction<string>}
 */
export declare function maxLength(length: number): ValidatorFunction<string>;
/**
 * This rule detects if the provided number is same or above the provided minValue
 * @param {number} minValue
 * @returns {ValidatorFunction<number>}
 */
export declare function min(minValue: number): ValidatorFunction<number>;
/**
 * This rule detects if the provided number is same or below the provided maxValue
 * @returns {ValidatorFunction<number>}
 * @param maxValue
 */
export declare function max(maxValue: number): ValidatorFunction<number>;
/**
 * This rule detects if the provided value is within the provided array
 * @param enumeration
 * @returns {boolean}
 */
export declare function isEnum(enumeration: any[]): ValidatorFunction<any[]>;
/**
 * This helper function runs a series of validator functions and returns false once a rule fails
 * @param {ValidatorFunction<any>[]} rules
 * @param value
 * @returns {boolean}
 */
export declare function parallelValidateBlock(rules: ValidatorFunction<any>[]): ((value: any) => true | string);
/**
 * This helper function runs a series of validator functions and returns false once a rule fails
 * @param {ValidatorFunction<any>[]} rules
 * @param value
 * @returns {boolean}
 */
export declare function parallelValidate(rules: ValidatorFunction<any>[], value?: any | undefined): true | string;

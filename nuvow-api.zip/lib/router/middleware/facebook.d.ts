import BasicError from "../../error/baseerror";
/**
 * This interface defines the data returned from a facebook token validation
 */
export interface FacebookAuthenticationData {
    name: string;
    email?: string;
    id: string;
}
/**
 * This class defines a generic error when communicating with the facebook API
 */
export declare class GenericFacebookError extends BasicError {
    encapsulatedError?: any;
    constructor(message?: string, error?: any);
}
/**
 * This class defines an error with the facebook api when the provided authentication token is not valid or expired
 */
export declare class FacebookTokenExpiredError extends GenericFacebookError {
    constructor(message?: string, error?: any);
}
/**
 * This function returns a promise containing FacebookAuthenticationData
 * @param {string} fb_token - A facebook authentication token with email access right
 * @returns {Promise<FacebookAuthenticationData>}
 */
export declare function validateFacebookToken(fb_token: string): Promise<FacebookAuthenticationData>;

import * as express from "express";
import * as Sequelize from "sequelize";
import { IncludeOptions, Model } from "sequelize";
import { DeviceInstance, UserInstance, WeddingInstance } from "../model";
import DBCache from "gradelo-db-cache";
import { ValidatorFunction } from "./middleware/validationrules";
export interface ExtendedSequelize extends Sequelize.Sequelize {
    dialect: Sequelize.QueryInterface;
}
export interface APIRequest<BodyParameters = any> extends express.Request {
    sequelize: ExtendedSequelize;
    db_cache?: DBCache;
    currentUser?: UserInstance;
    currentDevice?: DeviceInstance;
    currentWedding?: WeddingInstance;
    body: BodyParameters;
    token: string;
    invalidateCache(forToken?: string): void;
    isMobile(): boolean;
    aborted: boolean;
}
export declare type IncludeOptionsReturning = <T>(req: APIRequest<T>) => Array<Model<any, any> | IncludeOptions>;
export interface APIResponse extends express.Response {
    jsonContent(body: any, headers?: any | null, pagination?: any | null): any;
    setAuthCookie(token: string, unset?: boolean, admin?: boolean): any;
}
export interface ModelRouteRequest<Model, BodyParameters = any> extends APIRequest<BodyParameters> {
    currentModel: Model;
}
declare type ValidationContainer = {
    [key: string]: (ValidatorFunction<any> | ValidatorFunction<any>[] | ValidationContainer);
};
export declare class BasicRouter {
    internalRouter: express.Router;
    /**
     * Constructs a new basic router object
     */
    constructor();
    /**
     * This function returns the internal router object
     * @returns {express.Router} - Returns the internal router
     */
    getInternalRouter(): express.Router;
    /**
     * This function allows requiring keys for a request
     * @param keys - The keys that have to be present in the request body
     * @returns {Function} - Returns a middleware to use in express
     */
    static requireKeys(keys: Array<string>): express.RequestHandler;
    /**
     * This function allows requiring keys for a request
     * @param keys - The keys that have to be present in the request body
     * @returns {Function} - Returns a middleware to use in express
     */
    static requireKeysOfTypes(keys: ValidationContainer, keyPath?: string): express.RequestHandler;
    static populateModel(model: string | Sequelize.Model<any, any>, param: string, include?: Array<Model<any, any> | IncludeOptions> | IncludeOptionsReturning): (req: ModelRouteRequest<any, any>, res: APIResponse, next: express.NextFunction) => void;
}
export {};

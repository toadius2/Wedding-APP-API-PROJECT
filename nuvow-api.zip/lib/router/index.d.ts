declare const _default: {
    v1: import("./basicrouter").BasicRouter[];
};
export default _default;

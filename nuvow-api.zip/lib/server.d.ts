import * as express from "express";
import * as Sequelize from "sequelize";
import DBCache from 'gradelo-db-cache';
export default class Server {
    app: express.Express;
    db_cache?: DBCache;
    private sequelize;
    constructor(new_sequelize: Sequelize.Sequelize, port: number);
    private setupHTTPApp;
}

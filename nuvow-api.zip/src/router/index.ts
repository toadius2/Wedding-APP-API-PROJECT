import { Router } from "./v1";
export default {
    'v1': Router
}
